package com.itwillbs.service;

import java.util.List;
import javax.inject.Inject;
import org.springframework.stereotype.Service;
import com.itwillbs.domain.CardVO;
import com.itwillbs.persistence.CardDAO;

@Service
public class CardService {
    
    @Inject
    private CardDAO cardDAO;
    
    // 카드 등록
    public void registerCard(CardVO vo) {
        cardDAO.insertCard(vo);
    }
    
    // 카드 조회
    public CardVO getCard(int card_id) {
        return cardDAO.getCard(card_id);
    }
    
    // 카드 목록 조회
    public List<CardVO> getCardList() {
        return cardDAO.getCardList();
    }
    
    // 카드 정보 수정
    public void modifyCard(CardVO vo) {
        cardDAO.updateCard(vo);
    }
    
    // 카드 삭제
    public void removeCard(int card_id) {
        cardDAO.deleteCard(card_id);
    }
    
    // 회원별 카드 조회
    public List<CardVO> getCardByMember(int member_id) {
        return cardDAO.getCardByMember(member_id);
    }
}