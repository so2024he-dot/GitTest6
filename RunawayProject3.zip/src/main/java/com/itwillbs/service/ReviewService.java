package com.itwillbs.service;

import java.util.List;
import javax.inject.Inject;
import org.springframework.stereotype.Service;
import com.itwillbs.domain.ReviewVO;
import com.itwillbs.persistence.ReviewDAO;

@Service
public class ReviewService {
    
    @Inject
    private ReviewDAO reviewDAO;
    
    // 리뷰 등록
    public void registerReview(ReviewVO vo) {
        reviewDAO.insertReview(vo);
    }
    
    // 리뷰 목록 조회
    public List<ReviewVO> getReviewList() {
        return reviewDAO.getReviewList();
    }
    
    // 회원별 리뷰 조회
    public List<ReviewVO> getReviewByMember(int member_id) {
        return reviewDAO.getReviewByMember(member_id);
    }
    
    // 상품별 리뷰 조회
    public List<ReviewVO> getReviewByGoods(int goods_id) {
        return reviewDAO.getReviewByGoods(goods_id);
    }
    
    // 리뷰 삭제
    public void removeReview(ReviewVO vo) {
        reviewDAO.deleteReview(vo);
    }
}