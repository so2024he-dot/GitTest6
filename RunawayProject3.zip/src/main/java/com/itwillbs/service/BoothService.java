package com.itwillbs.service;

import java.util.List;
import javax.inject.Inject;
import org.springframework.stereotype.Service;
import com.itwillbs.domain.BoothVO;
import com.itwillbs.persistence.BoothDAO;

@Service
public class BoothService {
    
    @Inject
    private BoothDAO boothDAO;
    
    // 부스 예약
    public void reserveBooth(BoothVO vo) {
        boothDAO.insertBooth(vo);
    }
    
    // 부스 조회
    public BoothVO getBooth(int booth_id) {
        return boothDAO.getBooth(booth_id);
    }
    
    // 부스 목록 조회
    public List<BoothVO> getBoothList() {
        return boothDAO.getBoothList();
    }
    
    // 부스 예약 취소
    public void cancelBooth(int booth_id) {
        boothDAO.deleteBooth(booth_id);
    }
    
    // 회원별 부스 예약 조회
    public List<BoothVO> getBoothByMember(int member_id) {
        return boothDAO.getBoothByMember(member_id);
    }
    
    // 이용 가능한 부스 조회
    public List<BoothVO> getAvailableBooth() {
        return boothDAO.getAvailableBooth();
    }
}