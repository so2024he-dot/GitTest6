package com.itwillbs.service;

import java.util.List;
import javax.inject.Inject;
import org.springframework.stereotype.Service;
import com.itwillbs.domain.MemberVO;
import com.itwillbs.persistence.MemberDAO;

@Service
public class MemberService {
    
    @Inject
    private MemberDAO memberDAO;
    
    // 회원 등록
    public void registerMember(MemberVO vo) {
        memberDAO.insertMember(vo);
    }
    
    // 회원 조회
    public MemberVO getMember(int member_id) {
        return memberDAO.getMember(member_id);
    }
    
    // 회원 목록 조회
    public List<MemberVO> getMemberList() {
        return memberDAO.getMemberList();
    }
    
    // 회원 정보 수정
    public void modifyMember(MemberVO vo) {
        memberDAO.updateMember(vo);
    }
    
    // 회원 삭제
    public void removeMember(int member_id) {
        memberDAO.deleteMember(member_id);
    }
    
    // 로그인 체크
    public MemberVO loginCheck(MemberVO vo) {
        return memberDAO.loginCheck(vo);
    }
    
    // 이메일 중복 체크
    public boolean checkEmailDuplicate(String member_email) {
        int count = memberDAO.checkEmail(member_email);
        return count > 0;
    }
}