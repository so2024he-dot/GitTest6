package com.itwillbs.service;

import java.util.List;
import javax.inject.Inject;
import org.springframework.stereotype.Service;
import com.itwillbs.domain.GoodsListVO;
import com.itwillbs.persistence.GoodsListDAO;

@Service
public class GoodsListService {
    
    @Inject
    private GoodsListDAO goodsListDAO;
    
    // 상품 등록
    public void registerGoods(GoodsListVO vo) {
        goodsListDAO.insertGoods(vo);
    }
    
    // 상품 조회
    public GoodsListVO getGoods(int goods_id) {
        return goodsListDAO.getGoods(goods_id);
    }
    
    // 상품 목록 조회
    public List<GoodsListVO> getGoodsList() {
        return goodsListDAO.getGoodsList();
    }
    
    // 상품 정보 수정
    public void modifyGoods(GoodsListVO vo) {
        goodsListDAO.updateGoods(vo);
    }
    
    // 상품 삭제
    public void removeGoods(int goods_id) {
        goodsListDAO.deleteGoods(goods_id);
    }
    
    // 회원별 구매 상품 조회
    public List<GoodsListVO> getGoodsByMember(int member_id) {
        return goodsListDAO.getGoodsByMember(member_id);
    }
    
    // 상품 검색
    public List<GoodsListVO> searchGoods(String keyword) {
        return goodsListDAO.searchGoodsByKr(keyword);
    }
}