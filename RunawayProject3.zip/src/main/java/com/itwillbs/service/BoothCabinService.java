package com.itwillbs.service;

import java.util.List;
import javax.inject.Inject;
import org.springframework.stereotype.Service;
import com.itwillbs.domain.BoothCabinVO;
import com.itwillbs.persistence.BoothCabinDAO;

@Service
public class BoothCabinService {
    
    @Inject
    private BoothCabinDAO boothCabinDAO;
    
    // 부스+사물함 예약
    public void reserveBoothCabin(BoothCabinVO vo) {
        boothCabinDAO.insertBoothCabin(vo);
    }
    
    // 부스+사물함 조회
    public BoothCabinVO getBoothCabin(int room_id) {
        return boothCabinDAO.getBoothCabin(room_id);
    }
    
    // 부스+사물함 목록 조회
    public List<BoothCabinVO> getBoothCabinList() {
        return boothCabinDAO.getBoothCabinList();
    }
    
    // 부스+사물함 예약 취소
    public void cancelBoothCabin(int room_id) {
        boothCabinDAO.deleteBoothCabin(room_id);
    }
    
    // 회원별 부스+사물함 예약 조회
    public List<BoothCabinVO> getBoothCabinByMember(int member_id) {
        return boothCabinDAO.getBoothCabinByMember(member_id);
    }
}