package com.itwillbs.service;

import java.util.List;
import javax.inject.Inject;
import org.springframework.stereotype.Service;
import com.itwillbs.domain.PayVO;
import com.itwillbs.persistence.PayDAO;

@Service
public class PayService {
    
    @Inject
    private PayDAO payDAO;
    
    // 결제 등록
    public void processPay(PayVO vo) {
        payDAO.insertPay(vo);
    }
    
    // 결제 조회
    public PayVO getPay(int pay_id) {
        return payDAO.getPay(pay_id);
    }
    
    // 결제 목록 조회
    public List<PayVO> getPayList() {
        return payDAO.getPayList();
    }
    
    // 결제 상태 수정
    public void updatePayStatus(PayVO vo) {
        payDAO.updatePayStatus(vo);
    }
    
    // 결제 취소
    public void cancelPay(int pay_id) {
        payDAO.deletePay(pay_id);
    }
    
    // 회원별 결제 내역 조회
    public List<PayVO> getPayByMember(int member_id) {
        return payDAO.getPayByMember(member_id);
    }
    
    // 결제 상태별 조회
    public List<PayVO> getPayByStatus(String pay_status) {
        return payDAO.getPayByStatus(pay_status);
    }
}