package com.itwillbs.service;

import java.util.List;
import javax.inject.Inject;
import org.springframework.stereotype.Service;
import com.itwillbs.domain.CabinVO;
import com.itwillbs.persistence.CabinDAO;

@Service
public class CabinService {
    
    @Inject
    private CabinDAO cabinDAO;
    
    // 사물함 예약
    public void reserveCabin(CabinVO vo) {
        cabinDAO.insertCabin(vo);
    }
    
    // 사물함 조회
    public CabinVO getCabin(int cabinet_id) {
        return cabinDAO.getCabin(cabinet_id);
    }
    
    // 사물함 목록 조회
    public List<CabinVO> getCabinList() {
        return cabinDAO.getCabinList();
    }
    
    // 사물함 예약 취소
    public void cancelCabin(int cabinet_id) {
        cabinDAO.deleteCabin(cabinet_id);
    }
    
    // 회원별 사물함 예약 조회
    public List<CabinVO> getCabinByMember(int member_id) {
        return cabinDAO.getCabinByMember(member_id);
    }
    
    // 이용 가능한 사물함 조회
    public List<CabinVO> getAvailableCabin() {
        return cabinDAO.getAvailableCabin();
    }
}