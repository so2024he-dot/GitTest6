package com.itwillbs.domain;

import lombok.Data;

@Data
public class CardVO {
    private int card_id;
    private int member_id;
    private int pay_id;
    private String card_company;
    private String card_type;
    private int card_num;
    private int card_cvc;
    private String card_expire_date;
    private String card_name;
}
