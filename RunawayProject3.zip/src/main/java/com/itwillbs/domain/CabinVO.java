package com.itwillbs.domain;

import lombok.Data;

@Data
public class CabinVO {
    private int cabinet_id;
    private int member_id;
}
