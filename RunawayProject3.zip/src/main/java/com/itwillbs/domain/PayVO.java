package com.itwillbs.domain;

import lombok.Data;

@Data
public class PayVO {
    private int pay_id;
    private int cabinet_id;
    private int booth_id;
    private int room_id;
    private int member_id;
    private int pay_price;
    private String pay_method;
    private String pay_status;
    private String pay_date;
}