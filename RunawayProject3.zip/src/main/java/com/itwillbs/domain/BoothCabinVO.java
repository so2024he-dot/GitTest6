package com.itwillbs.domain;

import lombok.Data;

@Data
public class BoothCabinVO {
    private int room_id;
    private int cabinet_id;
    private int member_id;
}
