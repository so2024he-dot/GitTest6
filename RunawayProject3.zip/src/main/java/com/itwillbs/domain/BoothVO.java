package com.itwillbs.domain;

import lombok.Data;

@Data
public class BoothVO {
    private int booth_id;
    private int member_id;
}