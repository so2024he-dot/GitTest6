package com.itwillbs.domain;

import java.util.Date;
import lombok.Data;

@Data
public class MemberVO {
    private int member_id;
    private String member_pass;
    private String member_name;
    private String member_email;
    private Date member_birth;
    private Date member_date;
    private int member_phone;
    private String member_gender;
    private String member_addr;
}

