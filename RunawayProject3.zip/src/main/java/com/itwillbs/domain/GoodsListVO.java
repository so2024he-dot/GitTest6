package com.itwillbs.domain;

import lombok.Data;

@Data
public class GoodsListVO {
    private String goods_01;
    private String goods_06;
    private int goods_id;
    private String goods_name_kr;
    private String goods_name_en;
    private String goods_poster;
    private String my_info_02;
    private String GOODSLISTcol;
    private int member_id;
}