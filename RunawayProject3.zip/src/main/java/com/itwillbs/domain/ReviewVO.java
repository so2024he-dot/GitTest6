package com.itwillbs.domain;

import lombok.Data;

@Data
public class ReviewVO {
    private int member_id;
    private int goods_id;
}