package com.itwillbs.persistence;

import java.util.List;
import javax.inject.Inject;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import com.itwillbs.domain.CabinVO;

@Repository
public class CabinDAO {
    
    @Inject
    private SqlSession sqlSession;
    
    private static final String NAMESPACE = "com.itwillbs.mapper.CabinMapper";
    
    // 사물함 예약
    public void insertCabin(CabinVO vo) {
        sqlSession.insert(NAMESPACE + ".insertCabin", vo);
    }
    
    // 사물함 조회
    public CabinVO getCabin(int cabinet_id) {
        return sqlSession.selectOne(NAMESPACE + ".getCabin", cabinet_id);
    }
    
    // 사물함 목록 조회
    public List<CabinVO> getCabinList() {
        return sqlSession.selectList(NAMESPACE + ".getCabinList");
    }
    
    // 사물함 예약 취소
    public void deleteCabin(int cabinet_id) {
        sqlSession.delete(NAMESPACE + ".deleteCabin", cabinet_id);
    }
    
    // 회원별 사물함 예약 조회
    public List<CabinVO> getCabinByMember(int member_id) {
        return sqlSession.selectList(NAMESPACE + ".getCabinByMember", member_id);
    }
    
    // 이용 가능한 사물함 조회
    public List<CabinVO> getAvailableCabin() {
        return sqlSession.selectList(NAMESPACE + ".getAvailableCabin");
    }
}