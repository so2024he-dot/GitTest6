package com.itwillbs.persistence;

import java.util.List;
import javax.inject.Inject;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import com.itwillbs.domain.MemberVO;

@Repository
public class MemberDAO {
    
    @Inject
    private SqlSession sqlSession;
    
    private static final String NAMESPACE = "com.itwillbs.mapper.MemberMapper";
    
    // 회원 등록
    public void insertMember(MemberVO vo) {
        sqlSession.insert(NAMESPACE + ".insertMember", vo);
    }
    
    // 회원 조회 (ID)
    public MemberVO getMember(int member_id) {
        return sqlSession.selectOne(NAMESPACE + ".getMember", member_id);
    }
    
    // 회원 목록 조회
    public List<MemberVO> getMemberList() {
        return sqlSession.selectList(NAMESPACE + ".getMemberList");
    }
    
    // 회원 정보 수정
    public void updateMember(MemberVO vo) {
        sqlSession.update(NAMESPACE + ".updateMember", vo);
    }
    
    // 회원 삭제
    public void deleteMember(int member_id) {
        sqlSession.delete(NAMESPACE + ".deleteMember", member_id);
    }
    
    // 로그인 체크
    public MemberVO loginCheck(MemberVO vo) {
        return sqlSession.selectOne(NAMESPACE + ".loginCheck", vo);
    }
    
    // 이메일 중복 체크
    public int checkEmail(String member_email) {
        return sqlSession.selectOne(NAMESPACE + ".checkEmail", member_email);
    }
}