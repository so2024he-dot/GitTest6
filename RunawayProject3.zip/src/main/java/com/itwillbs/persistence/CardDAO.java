package com.itwillbs.persistence;

import java.util.List;
import javax.inject.Inject;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import com.itwillbs.domain.CardVO;

@Repository
public class CardDAO {
    
    @Inject
    private SqlSession sqlSession;
    
    private static final String NAMESPACE = "com.itwillbs.mapper.CardMapper";
    
    // 카드 등록
    public void insertCard(CardVO vo) {
        sqlSession.insert(NAMESPACE + ".insertCard", vo);
    }
    
    // 카드 조회
    public CardVO getCard(int card_id) {
        return sqlSession.selectOne(NAMESPACE + ".getCard", card_id);
    }
    
    // 카드 목록 조회
    public List<CardVO> getCardList() {
        return sqlSession.selectList(NAMESPACE + ".getCardList");
    }
    
    // 카드 정보 수정
    public void updateCard(CardVO vo) {
        sqlSession.update(NAMESPACE + ".updateCard", vo);
    }
    
    // 카드 삭제
    public void deleteCard(int card_id) {
        sqlSession.delete(NAMESPACE + ".deleteCard", card_id);
    }
    
    // 회원별 카드 조회
    public List<CardVO> getCardByMember(int member_id) {
        return sqlSession.selectList(NAMESPACE + ".getCardByMember", member_id);
    }
}