package com.itwillbs.persistence;

import java.util.List;
import javax.inject.Inject;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import com.itwillbs.domain.ReviewVO;

@Repository
public class ReviewDAO {
    
    @Inject
    private SqlSession sqlSession;
    
    private static final String NAMESPACE = "com.itwillbs.mapper.ReviewMapper";
    
    // 리뷰 등록
    public void insertReview(ReviewVO vo) {
        sqlSession.insert(NAMESPACE + ".insertReview", vo);
    }
    
    // 리뷰 목록 조회
    public List<ReviewVO> getReviewList() {
        return sqlSession.selectList(NAMESPACE + ".getReviewList");
    }
    
    // 회원별 리뷰 조회
    public List<ReviewVO> getReviewByMember(int member_id) {
        return sqlSession.selectList(NAMESPACE + ".getReviewByMember", member_id);
    }
    
    // 상품별 리뷰 조회
    public List<ReviewVO> getReviewByGoods(int goods_id) {
        return sqlSession.selectList(NAMESPACE + ".getReviewByGoods", goods_id);
    }
    
    // 리뷰 삭제
    public void deleteReview(ReviewVO vo) {
        sqlSession.delete(NAMESPACE + ".deleteReview", vo);
    }
}