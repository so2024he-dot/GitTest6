package com.itwillbs.persistence;

import java.util.List;
import javax.inject.Inject;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import com.itwillbs.domain.BoothVO;

@Repository
public class BoothDAO {
    
    @Inject
    private SqlSession sqlSession;
    
    private static final String NAMESPACE = "com.itwillbs.mapper.BoothMapper";
    
    // 부스 예약
    public void insertBooth(BoothVO vo) {
        sqlSession.insert(NAMESPACE + ".insertBooth", vo);
    }
    
    // 부스 조회
    public BoothVO getBooth(int booth_id) {
        return sqlSession.selectOne(NAMESPACE + ".getBooth", booth_id);
    }
    
    // 부스 목록 조회
    public List<BoothVO> getBoothList() {
        return sqlSession.selectList(NAMESPACE + ".getBoothList");
    }
    
    // 부스 예약 취소
    public void deleteBooth(int booth_id) {
        sqlSession.delete(NAMESPACE + ".deleteBooth", booth_id);
    }
    
    // 회원별 부스 예약 조회
    public List<BoothVO> getBoothByMember(int member_id) {
        return sqlSession.selectList(NAMESPACE + ".getBoothByMember", member_id);
    }
    
    // 이용 가능한 부스 조회
    public List<BoothVO> getAvailableBooth() {
        return sqlSession.selectList(NAMESPACE + ".getAvailableBooth");
    }
}