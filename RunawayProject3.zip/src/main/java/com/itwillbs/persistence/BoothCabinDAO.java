package com.itwillbs.persistence;

import java.util.List;
import javax.inject.Inject;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import com.itwillbs.domain.BoothCabinVO;

@Repository
public class BoothCabinDAO {
    
    @Inject
    private SqlSession sqlSession;
    
    private static final String NAMESPACE = "com.itwillbs.mapper.BoothCabinMapper";
    
    // 부스+사물함 예약
    public void insertBoothCabin(BoothCabinVO vo) {
        sqlSession.insert(NAMESPACE + ".insertBoothCabin", vo);
    }
    
    // 부스+사물함 조회
    public BoothCabinVO getBoothCabin(int room_id) {
        return sqlSession.selectOne(NAMESPACE + ".getBoothCabin", room_id);
    }
    
    // 부스+사물함 목록 조회
    public List<BoothCabinVO> getBoothCabinList() {
        return sqlSession.selectList(NAMESPACE + ".getBoothCabinList");
    }
    
    // 부스+사물함 예약 취소
    public void deleteBoothCabin(int room_id) {
        sqlSession.delete(NAMESPACE + ".deleteBoothCabin", room_id);
    }
    
    // 회원별 부스+사물함 예약 조회
    public List<BoothCabinVO> getBoothCabinByMember(int member_id) {
        return sqlSession.selectList(NAMESPACE + ".getBoothCabinByMember", member_id);
    }
}