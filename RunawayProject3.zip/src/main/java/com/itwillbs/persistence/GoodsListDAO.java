package com.itwillbs.persistence;

import java.util.List;
import javax.inject.Inject;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import com.itwillbs.domain.GoodsListVO;

@Repository
public class GoodsListDAO {
    
    @Inject
    private SqlSession sqlSession;
    
    private static final String NAMESPACE = "com.itwillbs.mapper.GoodsListMapper";
    
    // 상품 등록
    public void insertGoods(GoodsListVO vo) {
        sqlSession.insert(NAMESPACE + ".insertGoods", vo);
    }
    
    // 상품 조회
    public GoodsListVO getGoods(int goods_id) {
        return sqlSession.selectOne(NAMESPACE + ".getGoods", goods_id);
    }
    
    // 상품 목록 조회
    public List<GoodsListVO> getGoodsList() {
        return sqlSession.selectList(NAMESPACE + ".getGoodsList");
    }
    
    // 상품 정보 수정
    public void updateGoods(GoodsListVO vo) {
        sqlSession.update(NAMESPACE + ".updateGoods", vo);
    }
    
    // 상품 삭제
    public void deleteGoods(int goods_id) {
        sqlSession.delete(NAMESPACE + ".deleteGoods", goods_id);
    }
    
    // 회원별 구매 상품 조회
    public List<GoodsListVO> getGoodsByMember(int member_id) {
        return sqlSession.selectList(NAMESPACE + ".getGoodsByMember", member_id);
    }
    
    // 상품 검색 (한글명)
    public List<GoodsListVO> searchGoodsByKr(String keyword) {
        return sqlSession.selectList(NAMESPACE + ".searchGoodsByKr", keyword);
    }
}