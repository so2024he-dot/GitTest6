package com.itwillbs.persistence;

import java.util.List;
import javax.inject.Inject;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import com.itwillbs.domain.PayVO;

@Repository
public class PayDAO {
    
    @Inject
    private SqlSession sqlSession;
    
    private static final String NAMESPACE = "com.itwillbs.mapper.PayMapper";
    
    // 결제 등록
    public void insertPay(PayVO vo) {
        sqlSession.insert(NAMESPACE + ".insertPay", vo);
    }
    
    // 결제 조회
    public PayVO getPay(int pay_id) {
        return sqlSession.selectOne(NAMESPACE + ".getPay", pay_id);
    }
    
    // 결제 목록 조회
    public List<PayVO> getPayList() {
        return sqlSession.selectList(NAMESPACE + ".getPayList");
    }
    
    // 결제 상태 수정
    public void updatePayStatus(PayVO vo) {
        sqlSession.update(NAMESPACE + ".updatePayStatus", vo);
    }
    
    // 결제 취소
    public void deletePay(int pay_id) {
        sqlSession.delete(NAMESPACE + ".deletePay", pay_id);
    }
    
    // 회원별 결제 내역 조회
    public List<PayVO> getPayByMember(int member_id) {
        return sqlSession.selectList(NAMESPACE + ".getPayByMember", member_id);
    }
    
    // 결제 상태별 조회
    public List<PayVO> getPayByStatus(String pay_status) {
        return sqlSession.selectList(NAMESPACE + ".getPayByStatus", pay_status);
    }
}