package com.itwillbs.controller;

import java.util.List;
import javax.inject.Inject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import com.itwillbs.domain.PayVO;
import com.itwillbs.service.PayService;

@Controller
@RequestMapping("/pay")
public class PayController {
    
    @Inject
    private PayService payService;
    
    // 결제 처리
    @PostMapping("/process")
    @ResponseBody
    public ResponseEntity<String> processPay(@RequestBody PayVO vo) {
        try {
            payService.processPay(vo);
            return new ResponseEntity<>("결제 성공", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("결제 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    // 결제 조회
    @GetMapping("/{pay_id}")
    @ResponseBody
    public ResponseEntity<PayVO> getPay(@PathVariable int pay_id) {
        PayVO pay = payService.getPay(pay_id);
        return new ResponseEntity<>(pay, HttpStatus.OK);
    }
    
    // 결제 목록 조회
    @GetMapping("/list")
    @ResponseBody
    public ResponseEntity<List<PayVO>> getPayList() {
        List<PayVO> payList = payService.getPayList();
        return new ResponseEntity<>(payList, HttpStatus.OK);
    }
    
    // 회원별 결제 내역 조회
    @GetMapping("/member/{member_id}")
    @ResponseBody
    public ResponseEntity<List<PayVO>> getPayByMember(@PathVariable int member_id) {
        List<PayVO> memberPays = payService.getPayByMember(member_id);
        return new ResponseEntity<>(memberPays, HttpStatus.OK);
    }
    
    // 결제 상태별 조회
    @GetMapping("/status/{pay_status}")
    @ResponseBody
    public ResponseEntity<List<PayVO>> getPayByStatus(@PathVariable String pay_status) {
        List<PayVO> paysByStatus = payService.getPayByStatus(pay_status);
        return new ResponseEntity<>(paysByStatus, HttpStatus.OK);
    }
    
    // 결제 상태 수정
    @PutMapping("/{pay_id}/status")
    @ResponseBody
    public ResponseEntity<String> updatePayStatus(@PathVariable int pay_id, 
                                                  @RequestBody PayVO vo) {
        try {
            vo.setPay_id(pay_id);
            payService.updatePayStatus(vo);
            return new ResponseEntity<>("결제 상태 변경 성공", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("결제 상태 변경 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    // 결제 취소
    @DeleteMapping("/{pay_id}")
    @ResponseBody
    public ResponseEntity<String> cancelPay(@PathVariable int pay_id) {
        try {
            payService.cancelPay(pay_id);
            return new ResponseEntity<>("결제 취소 성공", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("결제 취소 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}