package com.itwillbs.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
    
    // 메인 페이지
    @GetMapping("/")
    public String home() {
        return "index";
    }
    
    // 서비스 소개 페이지
    @GetMapping("/services")
    public String services() {
        return "services";
    }
    
    // 기념품 페이지
    @GetMapping("/souvenirs")
    public String souvenirs() {
        return "souvenirs";
    }
    
    // 이벤트 페이지
    @GetMapping("/events")
    public String events() {
        return "events";
    }
    
    // 예약 페이지
    @GetMapping("/reservation")
    public String reservation() {
        return "reservation";
    }
}