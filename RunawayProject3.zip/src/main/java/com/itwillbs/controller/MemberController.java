package com.itwillbs.controller;

import java.util.List;
import javax.inject.Inject;
import javax.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.itwillbs.domain.MemberVO;
import com.itwillbs.service.MemberService;

@Controller
@RequestMapping("/member")
public class MemberController {
    
    @Inject
    private MemberService memberService;
    
    // 회원가입 폼
    @GetMapping("/register")
    public String registerForm() {
        return "member/register";
    }
    
    // 회원가입 처리
    @PostMapping("/register")
    @ResponseBody
    public ResponseEntity<String> register(@RequestBody MemberVO vo) {
        try {
            memberService.registerMember(vo);
            return new ResponseEntity<>("회원가입 성공", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("회원가입 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    // 로그인 폼
    @GetMapping("/login")
    public String loginForm() {
        return "member/login";
    }
    
    // 로그인 처리
    @PostMapping("/login")
    @ResponseBody
    public ResponseEntity<String> login(@RequestBody MemberVO vo, HttpSession session) {
        MemberVO member = memberService.loginCheck(vo);
        if (member != null) {
            session.setAttribute("member", member);
            return new ResponseEntity<>("로그인 성공", HttpStatus.OK);
        }
        return new ResponseEntity<>("로그인 실패", HttpStatus.UNAUTHORIZED);
    }
    
    // 로그아웃
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
    
    // 회원 목록 조회 (REST API)
    @GetMapping("/list")
    @ResponseBody
    public ResponseEntity<List<MemberVO>> getMemberList() {
        List<MemberVO> memberList = memberService.getMemberList();
        return new ResponseEntity<>(memberList, HttpStatus.OK);
    }
    
    // 회원 정보 조회 (REST API)
    @GetMapping("/{member_id}")
    @ResponseBody
    public ResponseEntity<MemberVO> getMember(@PathVariable int member_id) {
        MemberVO member = memberService.getMember(member_id);
        return new ResponseEntity<>(member, HttpStatus.OK);
    }
    
    // 회원 정보 수정
    @PutMapping("/{member_id}")
    @ResponseBody
    public ResponseEntity<String> updateMember(@PathVariable int member_id, 
                                               @RequestBody MemberVO vo) {
        try {
            vo.setMember_id(member_id);
            memberService.modifyMember(vo);
            return new ResponseEntity<>("회원정보 수정 성공", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("회원정보 수정 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    // 회원 삭제
    @DeleteMapping("/{member_id}")
    @ResponseBody
    public ResponseEntity<String> deleteMember(@PathVariable int member_id) {
        try {
            memberService.removeMember(member_id);
            return new ResponseEntity<>("회원 삭제 성공", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("회원 삭제 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    // 이메일 중복 체크
    @GetMapping("/check-email")
    @ResponseBody
    public ResponseEntity<Boolean> checkEmail(@RequestParam String email) {
        boolean isDuplicate = memberService.checkEmailDuplicate(email);
        return new ResponseEntity<>(isDuplicate, HttpStatus.OK);
    }
}