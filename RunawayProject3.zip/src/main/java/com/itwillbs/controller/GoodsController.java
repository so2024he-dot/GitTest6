package com.itwillbs.controller;

import java.util.List;
import javax.inject.Inject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import com.itwillbs.domain.GoodsListVO;
import com.itwillbs.service.GoodsListService;

@Controller
@RequestMapping("/goods")
public class GoodsController {
    
    @Inject
    private GoodsListService goodsListService;
    
    // 상품 등록
    @PostMapping("/register")
    @ResponseBody
    public ResponseEntity<String> registerGoods(@RequestBody GoodsListVO vo) {
        try {
            goodsListService.registerGoods(vo);
            return new ResponseEntity<>("상품 등록 성공", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("상품 등록 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    // 상품 조회
    @GetMapping("/{goods_id}")
    @ResponseBody
    public ResponseEntity<GoodsListVO> getGoods(@PathVariable int goods_id) {
        GoodsListVO goods = goodsListService.getGoods(goods_id);
        return new ResponseEntity<>(goods, HttpStatus.OK);
    }
    
    // 상품 목록 조회
    @GetMapping("/list")
    @ResponseBody
    public ResponseEntity<List<GoodsListVO>> getGoodsList() {
        List<GoodsListVO> goodsList = goodsListService.getGoodsList();
        return new ResponseEntity<>(goodsList, HttpStatus.OK);
    }
    
    // 상품 검색
    @GetMapping("/search")
    @ResponseBody
    public ResponseEntity<List<GoodsListVO>> searchGoods(@RequestParam String keyword) {
        List<GoodsListVO> searchResult = goodsListService.searchGoods(keyword);
        return new ResponseEntity<>(searchResult, HttpStatus.OK);
    }
    
    // 회원별 구매 상품 조회
    @GetMapping("/member/{member_id}")
    @ResponseBody
    public ResponseEntity<List<GoodsListVO>> getGoodsByMember(@PathVariable int member_id) {
        List<GoodsListVO> memberGoods = goodsListService.getGoodsByMember(member_id);
        return new ResponseEntity<>(memberGoods, HttpStatus.OK);
    }
    
    // 상품 수정
    @PutMapping("/{goods_id}")
    @ResponseBody
    public ResponseEntity<String> updateGoods(@PathVariable int goods_id, 
                                              @RequestBody GoodsListVO vo) {
        try {
            vo.setGoods_id(goods_id);
            goodsListService.modifyGoods(vo);
            return new ResponseEntity<>("상품 수정 성공", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("상품 수정 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    // 상품 삭제
    @DeleteMapping("/{goods_id}")
    @ResponseBody
    public ResponseEntity<String> deleteGoods(@PathVariable int goods_id) {
        try {
            goodsListService.removeGoods(goods_id);
            return new ResponseEntity<>("상품 삭제 성공", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("상품 삭제 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}