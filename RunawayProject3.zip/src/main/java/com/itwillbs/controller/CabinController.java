package com.itwillbs.controller;

import java.util.List;
import javax.inject.Inject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import com.itwillbs.domain.CabinVO;
import com.itwillbs.service.CabinService;

@Controller
@RequestMapping("/cabin")
public class CabinController {
    
    @Inject
    private CabinService cabinService;
    
    // 사물함 예약
    @PostMapping("/reserve")
    @ResponseBody
    public ResponseEntity<String> reserveCabin(@RequestBody CabinVO vo) {
        try {
            cabinService.reserveCabin(vo);
            return new ResponseEntity<>("사물함 예약 성공", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("사물함 예약 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    // 사물함 조회
    @GetMapping("/{cabinet_id}")
    @ResponseBody
    public ResponseEntity<CabinVO> getCabin(@PathVariable int cabinet_id) {
        CabinVO cabin = cabinService.getCabin(cabinet_id);
        return new ResponseEntity<>(cabin, HttpStatus.OK);
    }
    
    // 사물함 목록 조회
    @GetMapping("/list")
    @ResponseBody
    public ResponseEntity<List<CabinVO>> getCabinList() {
        List<CabinVO> cabinList = cabinService.getCabinList();
        return new ResponseEntity<>(cabinList, HttpStatus.OK);
    }
    
    // 이용 가능한 사물함 조회
    @GetMapping("/available")
    @ResponseBody
    public ResponseEntity<List<CabinVO>> getAvailableCabin() {
        List<CabinVO> availableCabins = cabinService.getAvailableCabin();
        return new ResponseEntity<>(availableCabins, HttpStatus.OK);
    }
    
    // 회원별 사물함 예약 조회
    @GetMapping("/member/{member_id}")
    @ResponseBody
    public ResponseEntity<List<CabinVO>> getCabinByMember(@PathVariable int member_id) {
        List<CabinVO> memberCabins = cabinService.getCabinByMember(member_id);
        return new ResponseEntity<>(memberCabins, HttpStatus.OK);
    }
    
    // 사물함 예약 취소
    @DeleteMapping("/{cabinet_id}")
    @ResponseBody
    public ResponseEntity<String> cancelCabin(@PathVariable int cabinet_id) {
        try {
            cabinService.cancelCabin(cabinet_id);
            return new ResponseEntity<>("사물함 예약 취소 성공", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("사물함 예약 취소 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}