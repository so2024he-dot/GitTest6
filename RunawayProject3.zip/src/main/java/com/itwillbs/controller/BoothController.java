package com.itwillbs.controller;

import java.util.List;
import javax.inject.Inject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import com.itwillbs.domain.BoothVO;
import com.itwillbs.service.BoothService;

@Controller
@RequestMapping("/booth")
public class BoothController {
    
    @Inject
    private BoothService boothService;
    
    // 부스 예약
    @PostMapping("/reserve")
    @ResponseBody
    public ResponseEntity<String> reserveBooth(@RequestBody BoothVO vo) {
        try {
            boothService.reserveBooth(vo);
            return new ResponseEntity<>("부스 예약 성공", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("부스 예약 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    // 부스 조회
    @GetMapping("/{booth_id}")
    @ResponseBody
    public ResponseEntity<BoothVO> getBooth(@PathVariable int booth_id) {
        BoothVO booth = boothService.getBooth(booth_id);
        return new ResponseEntity<>(booth, HttpStatus.OK);
    }
    
    // 부스 목록 조회
    @GetMapping("/list")
    @ResponseBody
    public ResponseEntity<List<BoothVO>> getBoothList() {
        List<BoothVO> boothList = boothService.getBoothList();
        return new ResponseEntity<>(boothList, HttpStatus.OK);
    }
    
    // 이용 가능한 부스 조회
    @GetMapping("/available")
    @ResponseBody
    public ResponseEntity<List<BoothVO>> getAvailableBooth() {
        List<BoothVO> availableBooths = boothService.getAvailableBooth();
        return new ResponseEntity<>(availableBooths, HttpStatus.OK);
    }
    
    // 회원별 부스 예약 조회
    @GetMapping("/member/{member_id}")
    @ResponseBody
    public ResponseEntity<List<BoothVO>> getBoothByMember(@PathVariable int member_id) {
        List<BoothVO> memberBooths = boothService.getBoothByMember(member_id);
        return new ResponseEntity<>(memberBooths, HttpStatus.OK);
    }
    
    // 부스 예약 취소
    @DeleteMapping("/{booth_id}")
    @ResponseBody
    public ResponseEntity<String> cancelBooth(@PathVariable int booth_id) {
        try {
            boothService.cancelBooth(booth_id);
            return new ResponseEntity<>("부스 예약 취소 성공", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("부스 예약 취소 실패", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}