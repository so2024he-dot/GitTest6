package com.itwillbs.web;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/spring/root-context.xml" })
public class SqlSessionFactoryTest {

	/**
	 * SqlSessionFactory 객체 주입시 에러발생 Mybatis-spring 라이브러리 버전 오류 3.0.4 -> 2.1.2 변경 문제
	 * 해결 버전 호환성 체크 완료
	 */
	// sqlSessionFactory 객체를 주입
	@Inject
	private SqlSessionFactory factory;

	@Test
	public void test_객체주인확인() {
		System.out.println("@@@@@@ factory : " + factory);
		
		System.out.println(" SQL 실행 확인 ");
		
		SqlSession sesssion = factory.openSession();
		// => 디비연결 & 실행 준비
		// => PreparedStatement와 유사한 동작
		
		// 내가 실행하고자 하는 동작에 따른 메서드를
		// 골라서 실행
//		session.delete("SQL");
//		session.insert("SQL");
//		session.rollback();
//		session.select("SQL");
//		session.update("SQL");
		
		
	}//test_객체주인확인()

}//SqlSessionFactoryTest