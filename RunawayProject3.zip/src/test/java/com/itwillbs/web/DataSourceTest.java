package com.itwillbs.web;

import java.sql.Connection;
import java.sql.DriverManager;
import org.junit.Test;

/**
 * Junit 개발테스트 도구를 사용해서 테스트
 * => 서버/메인메서드 없이 실행해서 테스트 가능하도록하는 라이브러리
 *
 */
public class DataSourceTest {
	
	private static final String DRIVER ="com.mysql.cj.jdbc.Driver";
	private static final String DBURAL ="jdbc:mysql://localhost:3306/springdb";
	private static final String DBID ="root";
	private static final String DBPW ="1234";
	
	// 디비연결
	// @Test : jUnit이 실행될 때 코드에  해당 어노테이션이 있을 때
	//         해당 메서드를 테스트코드를 인지하고 실행함
		
	@Test
	public void testDBConnect() throws Exception {
		
		Class.forName(DRIVER);
		System.out.println("드라이버 로드 성공!");
		Connection con = DriverManager.getConnection(DBURAL, DBID, DBPW);
		System.out.println("디비 연결 성공!");
		System.out.println("con : " + con);
	}
			
	
	
}
