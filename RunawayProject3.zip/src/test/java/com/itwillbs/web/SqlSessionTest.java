package com.itwillbs.web;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(
		locations = {"file:src/main/webapp/WEB-INF/spring/root-context.xml"}
		)
public class SqlSessionTest {
	
	//디비연결 객체를 주입
	@Autowired
	private SqlSession sqlSession;
	@Test
	public void test_객체확인() {
		System.out.println("@@@@@@@@@ 객체확인");
		System.out.println("sqlSession : " +sqlSession);
		System.out.println("디비연결 성공!");
		
		//sqlSession.inset(statement);
	}//test_객체확인()
}//SqlSessionTest
	
	

