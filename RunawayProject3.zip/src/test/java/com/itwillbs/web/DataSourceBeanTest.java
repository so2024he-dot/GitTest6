package com.itwillbs.web;

import java.sql.Connection;
import java.sql.SQLException;
import javax.inject.Inject;
import javax.sql.DataSource;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * 디비 연결정보를 직접 작성 X
 * root context.xml에서 만들어진 정보(객체)를 가져와서 사용
 *
 */
//@RunWith(SpringJUnit4ClassRunner.class)
//=> 해당 파일은 스프링 + jUnit4랑 같이 실행(테스트)하겠다. 
//@ContextConfiguration(
//		locations = {"file:src/main/webapp/WEB-INF/spring/root-context.xml"
//                     ,}
//		)
//=> 프로젝트의 설정파일의 위치지정

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(
		locations = {"file:src/main/webapp/WEB-INF/spring/root-context.xml"}
		)

public class DataSourceBeanTest {
	
	//@Inject (java)
    //@Autowired (spring
	// => 의존관계의 객체를 주입할 떼 사용
	//  root-context.xml에서 해당 객체를 찾아서 연결해줌
	//디비 연결정보
	//@Inject
    @Autowired
	private DataSource ds;
	@Test
	public void testCheck() {
		System.out.println("ds :" + ds);
	}//testCheck()
	
	public void testConnect(){
		try {
			Connection con = ds.getConnection();
			System.out.println("디비연결성공!");
			System.out.println("  con : " + con);
			}catch(SQLException e){
				e.printStackTrace();
			}//catch			
		}//testConnect	
}//DataSourceBeanTest
